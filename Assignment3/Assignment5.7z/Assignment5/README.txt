Name: Vladoi Marian
Email: vladoimarian@yahoo.com
Programming Partner: No Partner
OS: Windows
Asn#:5
Status: Completed
Files:
- counting.cpp
- printsquare.cpp
- numanalysis.cpp
- minvalue.cpp
- scores.cpp
- README.txt: Meta information about the homework files.

Hours on Lab Exercises: 3
Hours Working With Partner: 0
Hours Working Alone: 12
Hours Total: 15
Extra Credit:
- Completed program following pair-programming guidelines.
"Do you feel your mind getting numb yet?"