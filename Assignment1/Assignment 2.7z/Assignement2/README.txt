Name: Vladoi Marian
Email: vladoimarian@yahoo.com
Programming Partner: No Partner
OS: Windows
Asn#: 2
Status: Completed
Files:
- carcost.cpp
- math.cpp
- variables.cpp
- hellome.cpp
- erroneous.cpp
- syntax.txt
- compiling.txt
- README.txt: Meta information about the homework files.

Hours on Lab Exercises: 4
Hours Working With Partner: 0
Hours Working Alone: 12
Hours Total: 16
Extra Credit:
- Completed program following pair-programming guidelines