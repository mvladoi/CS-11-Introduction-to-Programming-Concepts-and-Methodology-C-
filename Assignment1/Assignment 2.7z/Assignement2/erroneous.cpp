
// Reviewed



/**
 * A very erroneous program.
 *
 * @author B. A. Ware
 * @version 1.0 1/25/05
 * The main functoin for the program.
 */


 #include <iostream>
 using namespace std;

int main() {
    cout << "Hello out there." << endl;
    cout << "My calculation is";
    cout << " " << 1.0 / 10; // 10%
    cout << " " << ", which means 10%" << endl;
   return 0;
} // end of main