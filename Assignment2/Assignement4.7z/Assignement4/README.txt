Name: Vladoi Marian
Email: vladoimarian@yahoo.com
Programming Partner: No Partner
OS: Windows
Asn#:4
Status: Completed
Files:
- invtable.cpp
- seasons.cpp
- spectrum.cpp
- monthdays.cpp
- comptime.cpp
- price.cpp
- grade.cpp
- loopy.cpp
- README.txt: Meta information about the homework files.

Hours on Lab Exercises: 3
Hours Working With Partner: 0
Hours Working Alone: 15
Hours Total: 18
Extra Credit:
- Completed program following pair-programming guidelines.