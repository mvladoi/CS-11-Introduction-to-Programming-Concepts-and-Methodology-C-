Name: Vladoi Marian
Email: vladoimarian@yahoo.com
Programming Partner: No Partner
OS: Windows
Asn#:6
Status: Completed
Files:
- dice.cpp
- stringdigits.cpp
- carcostfun.cpp
- scramble.cpp
- vowels.cpp
- doublefun.cpp
- absvalue.cpp
- trace.text
- README.txt: Meta information about the homework files.

Hours on Lab Exercises: 1
Hours Working With Partner: 0
Hours Working Alone: 13
Hours Total: 14
Extra Credit:
- Completed program following pair-programming guidelines.