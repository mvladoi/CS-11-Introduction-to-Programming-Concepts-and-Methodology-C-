/**
 * helloworld.cpp
 * Purpose: Prints a message to the screen.
 *
 * @author Ed Parrish
 * @version 1.0 8/30/05
 */
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!\n";
    return 0;
} // end of main function